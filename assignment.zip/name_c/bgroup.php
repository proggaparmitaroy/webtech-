<!DOCTYPE html>
<html>
<body>

<form >
	<fieldset>
		<legend>BLOOD GROUP</legend>
		<select required>
  <option value="">None</option>
  <option value="volvo">O+</option>
  <option value="saab">A-</option>
  <option value="mercedes">B+</option>
  <option value="audi">Ab+</option>
</select>
<br/><br/>
<hr/>
		<input type="submit" name="submit" value="Submit" >
		
	</fieldset>
</form>

</body>
</html>
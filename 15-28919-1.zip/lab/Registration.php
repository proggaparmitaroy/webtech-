<?php

	error_reporting(0);
		
	$uid = $erruid = $upass = $errupass"";
	$flag=1;
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$name=trim($_POST['name']);
		$email=trim($_POST['email']);
		$username=trim($_POST['username']);
		$password=trim($_POST['password']);
		$confirm password=trim($_POST['confirm_password']);
		$gender=trim($_POST['gender']);
		
		
		
		
	}
?>

<center>
<form method="post" action="#">
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
					<legend><h3>LOGIN</h3></legend>
					User Id<br/>
					<input type="text" name="uid" value="<?php echo $uid ?>"><span style="color:red;">*<?php echo $erruid ?></span><br/>                               
					Password<br/>
					<input type="password" name="upass" value="<?php echo $upass ?>"><span style="color:red;">*<?php echo $errupass ?></span>>
					<br /><hr/>
					<input type="button" value="Login">
					<a href="registration.html">Register</a>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>

<center>
<form method="post" action="#">
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
					<legend><h3>LOGIN</h3></legend>
					User Id<br/>
					<input type="text" name="uid" value="<?php echo $uid ?>"><span style="color:red;">*<?php echo $erruid ?></span><br/>                               
					Password<br/>
					<input type="password" name="upass" value="<?php echo $upass ?>"><span style="color:red;">*<?php echo $errupass ?></span>>
					<br /><hr/>
					<input type="button" value="Login">
					<a href="registration.html">Register</a>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>
<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
</head>
<body>
<form action="RegistrationHandler.php">
  <table width="50%" border="1">
   
  
    <tr>
   <td >
  <fieldset>

<legend> REGISTRATION </legend>

<table>
<tr>
<td>
<label> <b> Name </b> </label></td><td>:</td><td>
<input type="text" name="name"/></td></tr><br/>
<tr>
<td>
<label> <b> Email </b> </label> </td> <td> : </td>
<td> <input type="text" name="email"/></td></tr>

<tr>
<td> <label> <b> User Name </b> </label> </td><td>:</td>
<td> <input type="text" name="username"/></td>

<tr>
<td> <label> <b> Password </b></label></td> <td> : </td>
<td> <input type="password" name="password"/></td></tr>
<tr>
<td> <label> <b> Confirm Password </b></label></td> <td> : </td>
<td> <input type="password" name="confirm_password"/></td></tr>
</fieldset>

</table>
<table>
<fieldset>
<legend> Gender </legend>
     <input name="Gender" type="radio" value="Male"/>Male
   <input name="Gender" type="radio" value="Female"/>Female
   <input name="Gender" type="radio" value="Other"/>Other
</fieldset>
</table>


<fieldset>
   <table>   
   <legend> Date Of Birth </legend>
  <tr>
        <td> dd </td>
      <td> </td>
      <td> mm </td>
      <td> </td>
      <td> yyyy </td>
  </tr>
  <tr>
       <td> <input name="Date"></td>
       <td> / </td>
       <td> <input name="Month"> </td>
       <td> / </td>
       <td> <input name="Year"> (dd/mm/yyyy) </td>
  </tr>
  </table>
     </fieldset>

     <hr>




    

     <input type="submit" name="submit" value="submit"/>
     <input type="submit" name="submit" value="Reset"/>
 </tr>

  
</table>
</form>
</body>
</html>